import { Component, OnInit } from "@angular/core";
import { AppService } from "./../app.service";
import { Router } from "@angular/router";
import { User } from '../_models';
import { Subscription } from 'rxjs';
import { AuthenticationService } from '../shared/services';

@Component({
  selector: "app-sidebar",
  templateUrl: "./sidebar.component.html",
  styleUrls: ["./sidebar.component.scss"]
})
export class SidebarComponent implements OnInit {
  jobs: any = [];
  jobDetails: any = [];
  jobName;
  currentUser: User;
  currentUserSubscription: Subscription;

  constructor(private router: Router,
    private authenticationService: AuthenticationService) {
    this.currentUserSubscription = this.authenticationService.currentUser.subscribe(user => {
      this.currentUser = user;
      if (this.currentUser) {
          this.router.navigate(['/']);
      } else {
          this.router.navigate(['/login']);
      }
  });
  }

  ngOnInit() {
    this.getAllJobs();
  }

  getAllJobs() {
    this.appService.getAllJobs().subscribe(response => {
      this.jobs = response.jobs;
    });
  }

  navigateToJob(input) {
    this.jobName = input;
    this.router.navigate(["/job-details/" + this.jobName]);
  }
}
