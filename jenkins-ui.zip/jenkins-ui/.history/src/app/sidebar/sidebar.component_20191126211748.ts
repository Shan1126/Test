import { Component, OnInit } from '@angular/core';

type NewType = AppService;

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {
  constructor(private appService: NewType) { }

  ngOnInit() {
  }


  getAllJobs() {
    this.appService.getAllJobs().subscribe((response) => {
      this.jobs = response.jobs;
      this.getJobDetails();
    })
  }

}
