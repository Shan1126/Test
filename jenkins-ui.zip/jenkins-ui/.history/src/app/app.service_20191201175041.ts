import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';


@Injectable()
export class AppService {

  constructor(private http: HttpClient) {
  }

  getAllJobs() {
    return this.http.get<any>('/');
  }
  getJobsByName(name) {
    return this.http.get<any>('/'+name);
  }
  getBuildDetails(name, number) {
    return this.http.get<any>('/'+name+'/'+number);
  }
  getConsoleLog(name, number) {
    return this.http.get<any>('/'+name+'/'+number+'/log');
  }

  buildJob(name) {
    return this.http.post<any>(name, {});
  }
}