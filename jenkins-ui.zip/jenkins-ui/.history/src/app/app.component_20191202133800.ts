import { Component } from '@angular/core';
import { AppService } from './app.service';
import { Router, NavigationStart } from '@angular/router';
import { AuthenticationService } from './shared/services';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'jenkin-jobs';
  jobs: any = [];
  jobDetails: any = [];
  buildDetails: any = [];
  showHead: boolean = true;

  constructor(private authenticationService: AuthenticationService) {
  }

  ngOnInit() {
  }
  logout() {
    showHead: boolean = false;
    this.authenticationService.logout();
  }

}
