import { Component } from '@angular/core';
import { AppService } from './app.service';
import { Router, NavigationStart } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'jenkin-jobs';
  jobs: any = [];
  jobDetails: any = [];
  buildDetails: any = [];
  showHead: boolean = false;

  constructor() {
  // on route change to '/login', set the variable showHead to false
    router.events.forEach((event) => {
      if (event instanceof NavigationStart) {
        if (event['url'] == '/login') {
          this.showHead = false;
        } else {
          // console.log("NU")
          this.showHead = true;
        }
      }
    });
  }

  ngOnInit() {
    

  }

  getAllJobs() {
    this.appService.getAllJobs().subscribe((response) => {
      this.jobs = response.jobs;
      this.getJobDetails();
    })
  }

  buildJob(index) {
    this.appService.buildJob(this.jobs[index].name).subscribe((r) =>{
      // console.log(JSON.stringify(r));
    });
  }

  getJobDetails() {
    this.jobs.forEach((job, index) => {
      this.appService.getJobsByName(job.name).subscribe((response) => {
        this.jobDetails[index] = response;
        //console.log(`Job details for : ${job.name}: ${JSON.stringify(response)}`);
        if(job.builds) this.getBuildDetails(job.name, job.builds[0].number, index);
      })
    });
   
    
  }

  getBuildDetails(jobName, buildNumber, index) {
    this.appService.getBuildDetails(jobName, buildNumber).subscribe((response) => {
        this.buildDetails[index] = response;
        // console.log(`Last Build details for : ${jobName}, ${buildNumber}: ${JSON.stringify(response)}`);
    })
  }




  getOneJob() {
    this.appService.getJobsByName('mono-cleanup').subscribe((response) => {
      this.jobs[0] = response;
      this.getJobDetails();
      console.log(`Job details for mono-cleanup: ${JSON.stringify(response)}`);
    })
  }

  getSampleJobDetails(jobName, index) {
      //console.log('getting job details for ' + j.name);
      this.appService.getJobsByName(jobName).subscribe((response) => {
        this.jobDetails[index] = response;
        console.log(`Job details for : ${JSON.stringify(response)}`);
      })
  }

  logout()

}
