import { Component } from '@angular/core';
import { AppService } from './app.service';
import { Router, NavigationStart } from '@angular/router';
import { AuthenticationService } from './shared/services';
import { User } from './_models';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'jenkin-jobs';
  jobs: any = [];
  jobDetails: any = [];
  buildDetails: any = [];
  showHead: boolean = false;
  currentUser: User;
  currentUserSubscription: Subscription;

  constructor(private router: Router,
    private authenticationService: AuthenticationService) {
    this.currentUserSubscription = this.authenticationService.currentUser.subscribe(user => {
      this.currentUser = user;
      if (this.currentUser) {
          this.router.navigate(['/']);
          } else {
              this.router.navigate(['/login']);
      }
  });
  }

  ngOnInit() {
  }
  logout() {
    this.showHead = false;
    this.authenticationService.logout();
  }

}
