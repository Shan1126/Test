import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { JenkinsBuild } from './model/model';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';


@Injectable()
export class JenkinsService {

  constructor(private http: HttpClient) {
  }

  getLastBuildInfos(): Observable<JenkinsBuild> {
    return this.http.get<JenkinsBuild>(environment.Jenkins_API_URL);
  }


}