import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { JenkinsBuild } from './model/model';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';


@Injectable()
export class AppService {

  constructor(private http: HttpClient) {
  }

  getAllJobs() {
    return this.http.get<any>(environment.Jenkins_API_URL);
  }
  getJobsByName(name) {
    return this.http.get<any>(environment.Jenkins_API_URL+name);
  }
  getBuildDetails(name, number) {
    return this.http.get<any>(environment.Jenkins_API_URL+name+'/'+number);
  }
  getConsoleLog(name, number) {
    return this.http.get<any>(environment.Jenkins_API_URL+name+'/'+number);
  }

  buildJob(name) {
    return this.http.post<any>(environment.Jenkins_API_URL+name, {});
  }


}