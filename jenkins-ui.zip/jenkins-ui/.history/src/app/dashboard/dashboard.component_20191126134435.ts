import { Component, OnInit } from '@angular/core';
import {AppService} from './../app.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  jobs: any = [];
  jobDetails: any = [];
  buildDetails: any = [];
  constructor(private appService: AppService) {

  } 

  ngOnInit() {
    this.getAllJobs();

  }

  getAllJobs() {
    this.appService.getAllJobs().subscribe((response) => {
      this.jobs = response.jobs;
      console.log('Jobs: ' + JSON.stringify(this.jobs));
      // this.getJobDetails();
      this.getSampleJobDetails();
      this.getBuildDetails('mono-cleanup', 33605, 0);
    })
  }

  getJobDetails() {
    this.jobs.forEach((job, index) => {
      //console.log('getting job details for ' + j.name);
      this.appService.getJobsByName(job.name).subscribe((response) => {
        this.jobDetails[index] = response;
        console.log(`Job details for : ${job.name}: ${JSON.stringify(response)}`);
      })
    });
  }

  getBuildDetails(jobName, buildNumber, index) {
    this.appService.getBuildDetails(jobName, buildNumber).subscribe((response) => {
        this.buildDetails[index] = response;
        console.log(`Last Buuld details for : ${jobName}, ${buildNumber}: ${JSON.stringify(response)}`);
    })
  }

  getSampl====JobDetails(jobName, buildNumber, index) {
      //console.log('getting job details for ' + j.name);
      this.appService.getJobsByName('mono-cleanup/').subscribe((response) => {
        console.log(`Job details for : ${JSON.stringify(response)}`);
      })
  }

}
