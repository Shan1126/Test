import { Component, OnInit } from '@angular/core';
import {AppService} from './../app.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  jobs: any = [];
  jobDetails: any = [];
  buildDetails: any = [];
  constructor(private appService: AppService) {

  } 

  ngOnInit() {
    // this.getAllJobs();
    this.getOneJob();

  }

  getAllJobs() {
    this.appService.getAllJobs().subscribe((response) => {
      this.jobs = response.jobs;
      console.log('Jobs: ' + JSON.stringify(this.jobs));
    })
  }

  getOneJob() {
    this.appService.getJobsByName('mono-cleanup').subscribe((response) => {
      this.jobs[0] = response;
      this.getJobDetails();
      console.log(`Job details for mono-cleanup: ${JSON.stringify(response)}`);
    })
  }

  getJobDetails() {
    this.jobs.forEach((job, index) => {
      //console.log('getting job details for ' + j.name);
      this.appService.getJobsByName(job.name).subscribe((response) => {
        this.jobDetails[index] = response;
        console.log(`Job details for : ${job.name}: ${JSON.stringify(response)}`);
        this.getBuildDetails(job.name, job.builds[0].number, index);
      })
    });
   
    
  }

  getBuildDetails(jobName, buildNumber, index) {
    this.appService.getBuildDetails(jobName, buildNumber).subscribe((response) => {
        this.buildDetails[index] = response;
        console.log(`Last Build details for : ${jobName}, ${buildNumber}: ${JSON.stringify(response)}`);
    })
  }

  getSampleJobDetails(jobName, index) {
      //console.log('getting job details for ' + j.name);
      this.appService.getJobsByName(jobName).subscribe((response) => {
        this.jobDetails[index] = response;
        console.log(`Job details for : ${JSON.stringify(response)}`);
      })
  }

}
