import { Component, OnInit } from '@angular/core';
import {AppService} from './../app.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  jobs: any = [];
  jobDetails: any = [];
  constructor(private appService: AppService) {

  } 

  ngOnInit() {
    this.getAllJobs();
  }

  getAllJobs() {
    this.appService.getAllJobs().subscribe((response) => {
      this.jobs = response.jobs;
      this.getJobDetails();
      console.log('Jobs: ' + JSON.stringify(this.jobs));
    })
  }

  getJobDetails() {
    this.jobs.forEach((j, index) => {
      console.log('getting job details for ' + j.name);
    this.appService.getJobsByName(j.name).subscribe((response) => {
      this.jobDetails[index] = response;
      console.log(`Job details for : ${j.name}: ${JSON.stringify(response)}`);
    })
    });
  }

}
