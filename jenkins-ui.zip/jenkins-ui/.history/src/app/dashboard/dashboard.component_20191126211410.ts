import { Component, OnInit, Input } from '@angular/core';
import {AppService} from './../app.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  // jobs: any = [];
  // jobDetails: any = [];
  // buildDetails: any = [];

  @Input() jobs;
  @Input() jobDetails;
  @Input() buildDetails;
  constructor(private appService: AppService) {

  } 

  ngOnInit() {}

  buildJob(index) {
    this.appService.buildJob(this.jobs[index].name).subscribe((r) =>{
      // console.log(JSON.stringify(r));
    });
  }

}
