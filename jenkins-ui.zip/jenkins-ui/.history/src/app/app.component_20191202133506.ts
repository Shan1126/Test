import { Component } from '@angular/core';
import { AppService } from './app.service';
import { Router, NavigationStart } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'jenkin-jobs';
  jobs: any = [];
  jobDetails: any = [];
  buildDetails: any = [];
  showHead: boolean = false;

  constructor() {
  }

  ngOnInit() {
    

  }
  logout() {
    
  }

}
