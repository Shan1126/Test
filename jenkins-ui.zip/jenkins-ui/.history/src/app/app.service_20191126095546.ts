import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {AppComponent} from '../app.component';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import {Observable} from 'rxjs/Observable';
import {JenkinsBuild} from '../Model/jenkinsBuild';


@Injectable()
export class JenkinsService {

  constructor(private http: HttpClient) {
  }

  getLastBuildInfos(): Observable<JenkinsBuild> {
    return this.http.get<JenkinsBuild>(AppComponent.Jenkins_API_URL +
      '/lastBuild/api/json?tree=result,timestamp,estimatedDuration,fullDisplayName,building');
  }


}