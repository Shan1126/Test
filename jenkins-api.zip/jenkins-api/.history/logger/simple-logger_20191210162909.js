/* jshint esversion: 8*/

const logOptions = {
    logDirectory: './logs', // NOTE: folder must exist and be writable...
    fileNamePattern: 'jenkins-mw-log-<DATE>.log',
    dateFormat: 'YYYY.MM.DD'
};

var logger = {};

const log = require('simple-node-logger').createRollingFileLogger(logOptions);

function writeTraceLog(logContent) {
    log.trace(logContent);
}

function writeDebugLog(logContent) {
    log.debug(logContent);
}

function writeInfoLog(logContent) {
    log.info(logContent);
}

function writeWarnLog(logContent) {
    log.warn(logContent);
}

function writeErrorLog(logContent) {
    log.error(logContent);
}

function writeFatalLog(logContent) {
    log.fatal(logContent);
}

logger.writeTraceLog = writeTraceLog;
logger.writeDebugLog = writeDebugLog;
logger.writeInfoLog = writeInfoLog;
logger.writeWarnLog = writeWarnLog;
logger.writeErrorLog = writeErrorLog;
logger.writeFatalLog = writeFatalLog;

module.exports = logger;