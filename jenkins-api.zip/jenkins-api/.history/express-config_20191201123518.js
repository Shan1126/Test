(function (expressConfig) {

    var logger = require("./logger/simple-logger");
    var path = require('path');
    var expressValidator = require('express-validator');

    expressConfig.init = function (app, express) {

        api = express.Router();

        api.use(clientErrorHandler);

        function clientErrorHandler(err, req, res, next) {
            logger.writeErrorLog("error", "Something wrong with an XHR request "+ err.stack);

            if (req.xhr) {
                res.send(500, {error: 'Something blew up!'});
            } else {
                next(err);
            }
        }

        logger.writeDebugLog("Enabling GZip compression.");
        var compression = require('compression');
        app.use(compression({
            threshold: 512
        }));

        logger.writeDebugLog("Setting 'Public' folder with maxAge: 1 Day.");
        var publicFolder = path.dirname(module.parent.filename) + "/public";
        var oneYear = 31557600000;
        app.use(express.static(publicFolder, {maxAge: oneYear}));

        app.use(expressValidator({
            customValidators: {
                isFilePresent: function (value, filename) {
                    return filename !== undefined
                },
                isValidInput: function (value) {
                    return (value === 1 || value === 0);
                }
            }
        }));

        logger.writeDebugLog("Setting parse urlencoded request bodies into req.body.");


        logger.writeDebugLog("Overriding 'Express' logger");
        app.use(require('morgan')({"stream": logger.stream}));


    };

})(module.exports);