
var express = require('express');
var router = express.Router();
var logger = require('../logger/simple-logger');
var jenkinsapi = require('jenkins-api');
// var jenkins = require('jenkins')({ baseUrl: 'https://jenkins.mono-project.com/', crumbIssuer: true });
var jenkins = require('jenkins')({ baseUrl: 'http://jenkins_admin:Shan1230@localhost:8080', crumbIssuer: true });

// routes
router.get('/:name', getJobByName);
router.get('/', jobs);
router.post('/', buildJob);
module.exports = router;
function jobs(req,res) {
    jenkins.info(function(err, data) {
        if (err) throw err;
        // console.log('jobs', JSON.stringify(data));
        res.status(200).send(data);
    });
      
}
function getJobByName(req,res) {
    // jenkins.job.get(req.params.name, function(err, data) {
    //     if (err) throw err;
    //     res.status(200).send(data);
    //   });
      jenkins.build.get(req.params.name, function(err, data) {
        if (err){ return console.log(err); }
        res.status(200).send(data);
    });
}

function buildJob(req,res) {
    console.log(req.params.name)
    if(req.params.name) {
        jenkins.job.build(req.params.name, function(err, id) {
        if (err) throw err;
        res.status(200).send(waitOnQueue(id));
    });
}
function waitOnQueue(id) {
    jenkins.queue.item(id, function(err, item) {
      if (err) throw err;
      console.log('queue', item);
      if (item.executable) {
        console.log('number:', item.executable.number);
        return item.executable.number;
      } else if (item.cancelled) {
        console.log('cancelled');
        return 'canceled';
      } else {
        setTimeout(function() {
          waitOnQueue(id);
        }, 500);
      }
    });
  }