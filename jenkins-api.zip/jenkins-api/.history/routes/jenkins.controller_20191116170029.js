
var express = require('express');
var router = express.Router();
var logger = require('../logger/simple-logger');
var jenkins = require('jenkins')({ baseUrl: 'http://jenkins_admin:Shan1230@localhost:8080', crumbIssuer: true });


// routes
router.post('/jobs/all', alljobs);
module.exports = router;

function alljobs(req,res) {
    jenkins.job.list(function(err, data) {
        if (err) throw err;
        console.log('jobs', JSON.stringify(data));
    });
}