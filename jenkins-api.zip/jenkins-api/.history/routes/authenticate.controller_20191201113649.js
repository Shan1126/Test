const config = require('config.json');
var express = require('express');
var router = express.Router();
var authenticateService = require('services/authenticate.service');
// routes
router.post('/authenticate', authenticate);
module.exports = router;


function authenticate(req, res) {
    authenticateService.authenticate(req.body.email, req.body.password)
        .then(function (user) {
            if (user) {
                if(!user.isActive) {
                    // authentication pass, user is inactive
                    res.status(400).send({"message":"Your status is not active. Please contact your supervisor."});
                } else {
                    res.send(user);
                }

            }else {
                // authentication failed
                res.status(400).send({"message":"Username or password is incorrect"});
            }
        })
        .catch(function (err) {
            var m = {
                message: err
            }
            res.status(400).send(m);
        });
}



function register(req, res) {
    authenticateService.create(req, res)
        .then(function () {
            res.status(200).send({"message":"Registration successful. Please login."});
        })
        .catch(function (err) {
            var m = {
                message: err
            }
            res.status(400).send(m);
        });
}
function forgotPassword(req, res) {
    authenticateService.forgotPassword(req)
        .then(function () {
            res.status(200).send({"message":"Email sent successfully. Please check your email."});
        })
        .catch(function (err) {
            var m = {
                message: err
            }
            res.status(400).send(m);
        });
}

function _delete(req, res) {
    authenticateService.delete(req.params._id)
        .then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}


function verifyToken(req, res) {
    authenticateService.verifyToken(req)
        .then(function () {
            res.status(200).send({"validToken":true});
        })
        .catch(function (err) {
            var m = {
                validToken: false
            }
            res.status(400).send(m);
        });
}

function changePass(req, res) {
    authenticateService.changePass(req)
        .then(function () {
            res.status(200).send({"message":"Password changed Successfully."});
        })
        .catch(function (err) {
            var m = {
                message: err
            }
            res.status(400).send(m);
        });
}
