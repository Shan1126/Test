/*jshint esversion: 8 */

const express = require('express');
var router = express.Router();
const authenticate = require('../authenticate').default;
const https = require('https');
const appConstants = require('../constants');
var AWS = require('aws-sdk');
const axios = require("axios");
var logger = require('../logger/simple-logger');

//For Local Development
AWS.config.update({ region: 'us-east-2', endpoint: "http://localhost:8000" });

//For Live Service
// AWS.config.update({region: 'us-east-2'});

//The route handler for /fileValidate
router.get('/', async (req, res, next) => {    

    //Salesforce uses OAuth2.0 for authorization
    var oauthToken = await authenticate();
    //The response that we send for the fileValidate req
    var response = {};    

    if (oauthToken == null || oauthToken.token == null) {
        res.send({Error: 'Error while retrieving auth token'});
    } else {

        //Get Info To be displayed in the console
        getInfoData(contentVersionId, oauthToken.token)
        .then(fileInfoString => {
            var fileInfo = JSON.parse(fileInfoString);

            if (!Array.isArray(fileInfo)) {

                response.title = fileInfo.Title;
                response.VersionNumber = fileInfo.VersionNumber;
                response.ContentSize = fileInfo.ContentSize;

                SQSSend(contentVersionId);

                //Get the File using content Version ID if access token is obtained        
                getContentData(contentVersionId, oauthToken.token)
                    .then(fileContent => {

                        var isFileValid = fileValidate(fileContent);
                        response.isFileValid = isFileValid;
                        res.send(response);

                        SQSReceive();

                    })
                    .catch(err => {
                        console.log(err);
                        res.end();
                    });

            } else {
                console.log('Error: ', fileInfo.message);
                res.send({ 'Error': fileInfo.message });
            }

        }).catch(err => {
            console.log(err);
            res.end();
        });   

    } 
    
});

//Get the content of the document associated with the ContentVersion
const getContentData = function(contentVersionId , token) {

    return new Promise((resolve, reject) => {
        
        //var sfInstanceURL = token.instance_url == null ? appConstants.sfOrgURL : token.instance_url + '';
        var sfInstanceURL = appConstants.sfOrgURL;
        sfInstanceURL = sfInstanceURL.replace('https://', '');

        var sfFileReq_Options = {
            host: sfInstanceURL,
            path: getVersionDataRequestPath(appConstants.sfApiVersion, contentVersionId),        
            headers: {
                'accept': '/*',
                'authorization': 'Bearer ' + token.access_token
            }
        };  

        try {

            logger.writeInfoLog('Getting file content for ContentVersionID ', contentVersionId);
            var sf_FileContentRequest = https.get(sfFileReq_Options , (fileContentResponse) => {
                let fileContent = '';                

                fileContentResponse.on('data', chunk => {                    
                    fileContent += chunk;
                });

                fileContentResponse.on('error', error => {                    
                    reject(new Error('Error while reading FileContent: ', error.message));
                });

                fileContentResponse.on('end', () => {                                           
                    logger.writeInfoLog('File content received for ContentVersionID ', contentVersionId);
                    resolve(fileContent);
                });

            }).on('error', error => {                
                logger.writeErrorLog('Error while retreiving content for ContentVersionID ', contentVersionId, ' Error: ', error);
                reject(new Error('Error while reading FileContent: ', error.message));                
            });

            sf_FileContentRequest.end();
        } catch(err) {       
            logger.writeErrorLog('Error while retreiving content for ContentVersionID ', contentVersionId, ' Error: ', error);     
            reject(new Error('Error in SF_FileContent Get Request: ', err.message));
        }

    });

};

//Display info of the ContentVersion Document
const getInfoData = function(contentVersionID, token) {
    return new Promise((resolve, reject) => {

        var sfInstanceURL = appConstants.sfOrgURL;
        sfInstanceURL = sfInstanceURL.replace('https://', '');

        var sfFileReq_Options = {
            host: sfInstanceURL,
            path: getVersionInfoRequestPath(appConstants.sfApiVersion, contentVersionID),
            headers: {
                'accept': '/*',
                'authorization': 'Bearer ' + token.access_token
            }
        };

        try {            
            logger.writeInfoLog('Getting file Info for ContentVersionID ', contentVersionID);
            var sf_FileInfoRequest = https.get(sfFileReq_Options, (fileInfoResponse) => {
                let fileInfo = '';            

                fileInfoResponse.on('data', chunk => {
                    fileInfo += chunk;
                });

                fileInfoResponse.on('error', error => {
                    reject(new Error('Error while reading FileContent: ', error.message));
                });

                fileInfoResponse.on('end', () => {
                    logger.writeInfoLog('File Info received for ContentVersionID ', contentVersionID);
                    resolve(fileInfo);
                });
                
            }).on('error', error => {
                logger.writeErrorLog('Error while retreiving info for ContentVersionID ', contentVersionID, ' Error: ', error);
                reject(new Error('Error while reading FileContent: ', error.message));
            });

            sf_FileInfoRequest.end();
        } catch(err){
            logger.writeErrorLog('Error while retreiving info for ContentVersionID ', contentVersionID, ' Error: ', error);
            reject(new Error('Error while reading FileContent: ', error.message));
        }

    });
};

const postScanStatus = function(postBody, token) {

    return new Promise((resolve, reject) => {

        console.log('Data being posted to SF: ', postBody);        

        var sfInstanceURL = appConstants.sfOrgURL;
        sfInstanceURL = sfInstanceURL.replace('https://', '');

        var postStatusURL = sfInstanceURL + getPostStatusURL();    
        const headers = {
            'Content-Type': 'application/json',
            'authorization': 'Bearer ' + token.access_token
        };

        axios
            .post(postStatusURL, postBody, {
                headers: headers                
            })
            .then(function (response) {                
                console.log('Post Response from SF: ', response.data);                
                resolve(response.data);
            })
            .catch(function (error) {
                console.log(error);
                reject(error);
            });

    });

};

function getVersionDataRequestPath(sf_api_version, contentVersionId) {
    return `/services/data/v${sf_api_version}/sobjects/ContentVersion/${contentVersionId}/VersionData`;
}

function getVersionInfoRequestPath(sf_api_version, contentVersionId){
    return `/services/data/v${sf_api_version}/sobjects/ContentVersion/${contentVersionId}`;
}

function getPostStatusURL(){
    return `/services/apexrest/fileStatusUpdate/`;
}

/*
fileValidate : Boolean, returns true if file is valid, false if file is corrupted or invalid
*/
function fileValidate(fileContent) { //Use promise instead of boolean

    //Post to file Validation Service and get response
    if(fileContent == null) {
        console.log('FileContentReceived :', fileContent);
        return false;
    } else {
        return true;
    }

}

router.getContentData = getContentData;
router.getInfoData = getInfoData;
router.postScanStatus = postScanStatus;
module.exports = router;