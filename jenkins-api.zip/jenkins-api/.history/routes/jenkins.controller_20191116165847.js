
var express = require('express');
var router = express.Router();
var service = require('./savi.service');
var logger = require('../logger/simple-logger');

// routes
router.post('/', scanFile);
module.exports = router;

function scanFile(req,res) {
    logger.writeInfoLog('Calling SAVI Scan Service');
    service.scanFile(req)
    .then(function (user) {
        res.status(200).send(user);
    })
    .catch(function (err) {
        res.status(400).send(err);
    });
}