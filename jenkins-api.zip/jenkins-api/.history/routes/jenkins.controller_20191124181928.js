
var express = require('express');
var router = express.Router();
var logger = require('../logger/simple-logger');
var jenkins = require('jenkins')({ baseUrl: 'https://jenkins.mono-project.com/', crumbIssuer: true });


// routes
router.get('/:name', getJobByName);
router.get('/', alljobs);
module.exports = router;

function alljobs(req,res) {
     
}

function getJobByName(req,res) {
    jenkins.job.get(req.params.name, function(err, data) {
        if (err) throw err;
        res.status(200).send(data);
      });
}