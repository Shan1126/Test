
var express = require('express');
var router = express.Router();
var logger = require('../logger/simple-logger');
var jenkins = require('jenkins')({ baseUrl: 'http://jenkins_admin:Shan1230@localhost:8080', crumbIssuer: true });


// routes
router.get('/', alljobs);
router.get('/jobs/:name', getJob);
module.exports = router;

function getJob(req,res) {
    jenkins.job.list(function(err, data) {
        if (err) throw err;
        console.log('jobs', JSON.stringify(data));
        res.status(200).send(data);
    });
}

function alljobs(req,res) {
    jenkins.job.get(req.query.name, function(err, data) {
        if (err) throw err;
        res.status(200).send(data);
      });
}