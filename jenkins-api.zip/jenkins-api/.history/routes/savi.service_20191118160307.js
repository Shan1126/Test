/*jshint esversion: 8 */

// Load the AWS SDK for Node.js
const AWS = require("aws-sdk");
const constants = require("../constants");
var Q = require("q");
var async = require("async");
const axios = require("axios");
const fileValidate = require("./filevalidate");
const authenticate = require("../authenticate");
var logger = require('../logger/simple-logger');

//For Local Development - to use DynamoDB
// AWS.config.update({ region: 'us-east-2', endpoint: "http://localhost:8000" });

//For Live Service
AWS.config.update({region: 'us-east-2'});
const sqs = new AWS.SQS({ apiVersion: "2012-11-05" });
const queueURL = constants.SAVIQueueURL;
var service = {};

service.scanFile = scanFile;
module.exports = service;

function scanFile(req, res) {
  var deferred = Q.defer();
  var oauthToken;

  //DynamoDB not required
  // const ddb = new AWS.DynamoDB.DocumentClient();

  let base64FileString;
  var fileInfoData;  
  let scanResponse = '';
  var postBody;
  var virusFile =  false;

  async.series(
    [
      async function(callback) {
        console.log("Step 1");
        logger.writeInfoLog('Step 1 : Retreiving OAuth Token from Salesforce');
        oauthToken = await authenticate();
        if (oauthToken) {
          console.log("oauth Token is: " + JSON.stringify(oauthToken));
          logger.writeInfoLog('OAuth Token Received');
        }
      },
      async function (callback) {
        console.log('Getting File information ', req.query.contentVersionID,' ', oauthToken.token);
        await fileValidate
          .getInfoData(req.query.contentVersionID, oauthToken.token)
          .then(fileInfoString => {
            fileInfoData = JSON.parse(fileInfoString);            
            var insertParams = {
              TableName: 'SAVI_FileValidate',
              Item: {
                'ID': fileInfoData.Id,
                'VersionID': fileInfoData.VersionNumber + ' - ' + (new Date()).getTime(), //include timestamp for now, as dynamodb expects unique sort key for each hash key
                'Name': fileInfoData.Title,
                'ResponseStatus':'NotComplete',
                'URL': fileInfoData.attributes.url, //Change the url
                'ResponseDateTime': (new Date()).toTimeString(),
                'IsInfected' : false
              }
            };
          });
      },
      async function(callback) {
        console.log("Step 2: File retrieval");
        await fileValidate
          .getContentData(req.query.contentVersionID, oauthToken.token)
          .then(fileContent => {
            if(Buffer.from(fileContent).toString().includes('EICAR-STANDARD-ANTIVIRUS')) {
              virusFile = true
              console.log("Virus file retrieved... ");
            }
            base64FileString = Buffer.from(fileContent).toString("base64");
            console.log("Base 64 file: " + base64FileString);
          })
          .catch(err => {
            console.log(err);
            deferred.reject({
              message: "Error while extracting file from SF",
              statusCode: 500
            });
          });
      },      
      async function(callback) {
        console.log("Step 3 : Base 64 conversion and scan api call");
        let data = JSON.stringify({
          base64_string: base64FileString
        });
        
        const headers = {
          'Content-Type': 'application/json'
        };

        logger.writeInfoLog('Posting File ', fileInfoData.Id,' to CLAM Service for validation');
        // await axios
        //   .post(constants.CLAMAVServiceURL + 'scanfile', data, {
        //     headers: headers,
        //     timeout: 400000
        //   })
        //   .then(function(response) {
        //     console.log('Response from CLAM: ',response.data); 
        //     logger.writeInfoLog('Response from Clam: ', response.data, ' for File: ', fileInfoData.Id);          
        //     scanResponse = response.data;
        //   })
        //   .catch(function(error) {
        //     logger.writeErrorLog('Error while scanning File', fileInfoData.Id,' at CLAM ', err);
        //     console.log(error);
        //   });    
        if(virusFile)  {
          scanResponse = {scanStatus: 'Virus Found', virusFound: 1 };
        } else {
          scanResponse = {scanStatus: 'No virus found', virusFound: 0}
        }    
      },
      /*

      Do we need a step 4 now that we do not use DynamoDB?


      function(callback) {
        console.log("Step 4: DynamoDB status update");
        //update data into dynamodb
        var updateParmas = {
          TableName: 'SAVI_FileValidate',
          Key:{
            'ID': fileInfoData.Id,
            'VersionID': fileInfoData.VersionNumber
          },
          UpdateExpression: 'set ResponseStatus = :status, ResponseDateTime = :date, IsInfected = :fileStatus',
          ExpressionAttributeValues : {
            ":status" : "Completed",
            ":date": (new Date()).toTimeString(),
            ":fileStatus": (scanResponse === "virus found")
          },
          ReturnValues: "UPDATED_NEW"
        };        

        callback(null);    
      },
      */
      async function(callback) {        
        console.log("Step 5");

        postBody = {
          "fileContentVersionID": fileInfoData.Id,
          "lastScanDate": (new Date()).toISOString(),
          "scanStatus": scanResponse.scanStatus,
          "virusFound": scanResponse.virusFound
        };  
      }
    ],
    function(err) {
      if (err) {
        logger.writeErrorLog('Error in savi.service ', err);
        deferred.reject(err.name + ": " + err.message);
      }      
      console.log("Step Resolve");
      logger.writeInfoLog('savi.service completed successfully');
      deferred.resolve(postBody);
    }
  );

  return deferred.promise;
}