const express = require("express");
const https = require("https");
var request = require("request");
var parser = require("xml2json");
var cronParser = require("cron-parser");
var Q = require("q");

const router = express.Router();
var config = require("./../config.json");
const logger = require("../logger/simple-logger");
const jenkins = require("jenkins")({
  baseUrl: process.env.jenkins_url,
  crumbIssuer: true
});

// routes
router.get("/:name", getJobByName);
router.post("/", getNextRunTime);
router.get("/:name/:buildNumber", getBuildDetails);
router.get("/", getAllJobs);
// router.post('/:name', buildJob);
router.get("/:name/:buildNumber/log", getConsoleLog);
module.exports = router;

function getConsoleLog(req, res) {
  if (req.params.name) {
    jenkins.build.log(req.params.name, req.params.buildNumber, function(
      err,
      data
    ) {
      if (err) {
        return console.log(err);
      }
      res.status(200).send({ data: data });
    });
  } else {
    res.status(200).send({});
  }
}

function jobs(req, res) {
  jenkins.info(function(err, data) {
    if (err) throw err;
    var lst = [];
    data.jobs.forEach(j => {
      if (config.allowedApps.indexOf(j.name) > -1) {
        lst.push(j);
      }
    });
    data.jobs = lst;
    res.status(200).send(data);
  });
}
function getJobByName(req, res) {
  if (req.params.name) {
    jenkins.job.get(req.params.name, function(err, data) {
      if (err) {
        console.log(err);
      }
      res.status(200).send(data);
    });
  } else {
    res.status(200).send({});
  }
}
function getAllJobs(req, res) {
  request(process.env.jenkins_url + config.getJobsUrl, function(
    error,
    response,
    body
  ) {
    res.status(200).send(body);
  });
}
function getNextRunTime(req, res) {
var job= {};
  request(
    process.env.jenkins_url + "/job/" + req.body.jobName + "/config.xml",
    function(error, response, body) {
      // console.log('XML: ' + body);
      var jsonObj = JSON.parse(parser.toJson(body));
      //console.log('JSON: ' + JSON.stringify(jsonObj));
      if (
        jsonObj.project &&
        jsonObj.project.triggers &&
        jsonObj.project.triggers["hudson.triggers.TimerTrigger"] &&
        jsonObj.project.triggers["hudson.triggers.TimerTrigger"].spec
      ) {
        var interval = cronParser.parseExpression(
          jsonObj.project.triggers["hudson.triggers.TimerTrigger"].spec
        );
        job.name = j;
        job.nextTime = interval.next();
        res.status(200).send(job);
      } else {
        res.status(200).send(null); 
      }
    }
  );
}
function getBuildDetails(req, res) {
  if (req.params.name) {
    jenkins.build.get(req.params.name, req.params.buildNumber, function(
      err,
      data
    ) {
      if (err) {
        return console.log(err);
      }
      res.status(200).send(data);
    });
  } else {
    res.status(200).send({});
  }
}

// function buildJob(req,res) {
//     if(req.params.name) {
//         jenkins.job.build(req.params.name, function(err, id) {
//         if (err) throw err;
//         waitOnQueue(id);
//         res.status(200).send({});
//     });
//     } else {
//         waitOnQueue(id);
//         res.status(200).send({});
//     }
// }
function waitOnQueue(id) {
  jenkins.queue.item(id, function(err, item) {
    if (err) throw err;
    console.log("queue", item);
    if (item.executable) {
      console.log("number:", item.executable.number);
      return item.executable.number;
    } else if (item.cancelled) {
      console.log("cancelled");
      return "canceled";
    } else {
      setTimeout(function() {
        waitOnQueue(id);
      }, 500);
    }
  });
}
