const config = require('config.json');
var express = require('express');
var router = express.Router();
var authenticateService = require('services/authenticate.service');
// routes
router.post('/authenticate', authenticate);
router.post('/search-jobs', searchJobs);
router.post('/signup', register);
router.post('/forgotPassword', forgotPassword);
router.post('/changePass', changePass);
router.post('/verifyToken', verifyToken);
router.post('/locations', getLocations);
router.post('/newCustomer', createCompany);
router.get('/position/:_id', getJobById);
router.get('/:_id', getPosition);
router.get('/positions/featured', getFeaturedJobs);
router.get('/invitation/:_id', getInvitedUser);
router.post('/confirmEmail', confirmEmail);
router.post('/companyCheck/new', checkCompany);
module.exports = router;

function checkCompany(req, res) {
    authenticateService.checkCompany(req)
        .then(function (doc) {
            if(doc === '404') {
                var d = {};
                d.message =  'Your company has already been registered. Please contact your admin for creating your account.';
                d.code = 404;
                res.status(200).send(d);
            } else {
                var d = {}
                d.message =  '';
                d.code = 200;
                res.status(200).send(d);
            }
        })
        .catch(function (err) {
            res.status(500).send(err);
        });
}

function confirmEmail(req, res) {
    authenticateService.confirmEmail(req)
        .then(function (user) {
            res.status(200).send(user);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function getInvitedUser(req, res) {
    authenticateService.getInvitedUser(req)
        .then(function (code) {
            res.status(200).send(code);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function createCompany(req, res) {
    companyService.createCompany(req)
        .then(function (doc) {
            if(doc === '404') {
                var d = {};
                d.message =  'Sorry, it looks like there is already an account associated with the given admin details. You cannot create duplicate accounts.';
                d.code = 404;
                res.status(200).send(d);
            } else {
                var d = {}
                d.message =  '';
                d.code = 200;
                res.status(200).send(d);
            }
        })
        .catch(function (err) {
            res.status(500).send(err);
        });
}
function getFeaturedJobs(req, res){
    positionService.getFeaturedJobs(req)
        .then(function (data) {
            res.status(200).send(data);
        })
        .catch(function (err) {
            res.status(500).send(err);
        })
}


function getPosition(req, res){
    positionService.getPosition(req)
        .then(function (data) {
            res.status(200).send(data);
        })
        .catch(function (err) {
            res.status(500).send(err);
        })
}
function getLocations(req, res) {
    authenticateService.getLocations(req)
        .then(function (locs) {
            if (locs) {
                res.status(200).send(locs);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(500).send(err);
        });
}

function getJobById(req, res) {
    positionService.getPosition(req)
        .then(function (position) {
            if (position) {
                res.status(200).send(position);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(500).send(err);
        });
}
function searchJobs(req, res) {
    authenticateService.searchJobs(req)
        .then(function (jobs) {
            if (jobs) {
                res.status(200).send(jobs);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(500).send(err);
        });
}

function authenticate(req, res) {
    authenticateService.authenticate(req.body.email, req.body.password)
        .then(function (user) {
            if (user) {
                if(!user.isActive) {
                    // authentication pass, user is inactive
                    res.status(400).send({"message":"Your status is not active. Please contact your supervisor."});
                } else {
                    res.send(user);
                }

            }else {
                // authentication failed
                res.status(400).send({"message":"Username or password is incorrect"});
            }
        })
        .catch(function (err) {
            var m = {
                message: err
            }
            res.status(400).send(m);
        });
}



function register(req, res) {
    authenticateService.create(req, res)
        .then(function () {
            res.status(200).send({"message":"Registration successful. Please login."});
        })
        .catch(function (err) {
            var m = {
                message: err
            }
            res.status(400).send(m);
        });
}
function forgotPassword(req, res) {
    authenticateService.forgotPassword(req)
        .then(function () {
            res.status(200).send({"message":"Email sent successfully. Please check your email."});
        })
        .catch(function (err) {
            var m = {
                message: err
            }
            res.status(400).send(m);
        });
}

function _delete(req, res) {
    authenticateService.delete(req.params._id)
        .then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}


function verifyToken(req, res) {
    authenticateService.verifyToken(req)
        .then(function () {
            res.status(200).send({"validToken":true});
        })
        .catch(function (err) {
            var m = {
                validToken: false
            }
            res.status(400).send(m);
        });
}

function changePass(req, res) {
    authenticateService.changePass(req)
        .then(function () {
            res.status(200).send({"message":"Password changed Successfully."});
        })
        .catch(function (err) {
            var m = {
                message: err
            }
            res.status(400).send(m);
        });
}
