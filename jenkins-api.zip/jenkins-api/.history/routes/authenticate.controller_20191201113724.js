var express = require('express');
var router = express.Router();
var authenticateService = require('services/authenticate.service');
// routes
router.post('/authenticate', authenticate);
module.exports = router;


function authenticate(req, res) {
    authenticateService.authenticate(req.body.userId, req.body.password)
        .then(function (user) {
            if (user) {
                res.send(user);
            }else {
                // authentication failed
                res.status(400).send({"message":"Username or password is incorrect"});
            }
        })
        .catch(function (err) {
            var m = {
                message: err
            }
            res.status(400).send(m);
        });
}
