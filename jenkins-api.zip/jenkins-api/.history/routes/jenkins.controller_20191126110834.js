
var express = require('express');
var router = express.Router();
var logger = require('../logger/simple-logger');
// var jenkins = require('jenkins')({ baseUrl: 'https://jenkins.mono-project.com/', crumbIssuer: true });
var jenkins = require('jenkins')({ baseUrl: 'https://localhost:8080/', crumbIssuer: true });


// routes
router.get('/:name', getJobByName);
router.get('/', jobs);
module.exports = router;

function alljobs(req,res) {
    jenkins.job.list(function(err, data) {
        if (err) throw err;
        // console.log('jobs', JSON.stringify(data));
        res.status(200).send(data);

    });
}
function jobs(req,res) {
    jenkins.info(function(err, data) {
    if (err) throw err;
    // console.log('jobs', JSON.stringify(data));
    res.status(200).send(data);

});
}

function getJobByName(req,res) {
    jenkins.job.get(req.params.name, function(err, data) {
        if (err) throw err;
        res.status(200).send(data);
      });
}