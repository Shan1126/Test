
const express = require('express');
const https = require('https');

const router = express.Router();
var config = require('./../config.json');
const logger = require('../logger/simple-logger');
const jenkins = require('jenkins')({ baseUrl: process.env.jenkins_url, crumbIssuer: true });

// routes
router.get('/:name', getJobByName);
router.get('/:name/:buildNumber', getBuildDetails);
router.get('/', jobs);
// router.post('/:name', buildJob);
router.get('/:name/:buildNumber/log', getConsoleLog);
module.exports = router;

function getConsoleLog(req,res) {
    if(req.params.name) {
        jenkins.build.log(req.params.name, req.params.buildNumber, function(err, data) {
            if (err){ return console.log(err); }
            res.status(200).send({data:data});
        });
    } else {
        res.status(200).send({});
    }
}

function jobs(req,res) {
    jenkins.info(function(err, data) {
        if (err) throw err;
        var lst = [];
        data.jobs.forEach(j=> {
            if(config.allowedApps.indexOf(j.name) > -1) {
                lst.push(j);
            }
        })
        data.jobs = lst;
        res.status(200).send(data);
    });
      
}
function getJobByName(req,res) {
    if(req.params.name) {
        jenkins.job.get(req.params.name, function(err, data) {
            if (err){
                  console.log(err);
            }
            res.status(200).send(data);
        });
    } else {
        res.status(200).send({});
    }
}
function getJobDetailsByName(req,res) {
    if(req.params.name) {
        https.get(process.env.jenkins_url+config.getJobsUrl, (resp) => {
  let data = '';

  // A chunk of data has been recieved.
  resp.on('data', (chunk) => {
    data += chunk;
  });

  // The whole response has been received. Print out the result.
  resp.on('end', () => {
    console.log(JSON.parse(data).explanation);
  });

}).on("error", (err) => {
  console.log("Error: " + err.message);
});
    } else {
        res.status(200).send({});
    }
}
function getBuildDetails(req,res) {
    if(req.params.name) {
        jenkins.build.get(req.params.name, req.params.buildNumber, function(err, data) {
            if (err){ return console.log(err); }
            res.status(200).send(data);
        });
    } else {
        res.status(200).send({});
    }
}

// function buildJob(req,res) {
//     if(req.params.name) {
//         jenkins.job.build(req.params.name, function(err, id) {
//         if (err) throw err;
//         waitOnQueue(id);
//         res.status(200).send({});
//     });
//     } else {
//         waitOnQueue(id);
//         res.status(200).send({});
//     }
// }
function waitOnQueue(id) {
    jenkins.queue.item(id, function(err, item) {
      if (err) throw err;
      console.log('queue', item);
      if (item.executable) {
        console.log('number:', item.executable.number);
        return item.executable.number;
      } else if (item.cancelled) {
        console.log('cancelled');
        return 'canceled';
      } else {
        setTimeout(function() {
          waitOnQueue(id);
        }, 500);
      }
    });
  }