
var express = require('express');
var router = express.Router();
var logger = require('../logger/simple-logger');

// routes
router.post('/jobs/all', alljobs);
module.exports = router;

function scanFile(req,res) {
}