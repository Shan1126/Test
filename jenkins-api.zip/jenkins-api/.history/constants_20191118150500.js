//Ouath Access Token
const oauthAccessTokenHost = 'https://ocean1--oceandsg1.my.salesforce.com'
const oauthAccessTokenPath = '/services/oauth2/token'
const sfUserName = 'shan@radiantt.com.oceandsg1'
const sfPassword = 'Welcome@2019'
const oauthSecurityToken = 'gB3NtwgWcgSYAGP9WR8iKWih'// This Security Token will change is password is changed

// Credentials of Connected App - SF_JOB
const clientID = '3MVG9ic.6IFhNpPqaR1k03aR9fUx47WN60RkO4wncfi41vFNTpXugDOfyTEmlZ8x0kMB_c1yfapOkHa_vt7g2'
const clientSecret = '4C009C86A4AB83BC23409933728B37BC2ADE5E3736E52AC3696187E4B1D494EE'
const sfOrgURL = 'https://ocean1--oceandsg1.my.salesforce.com' //Use the org url or the instance url returned from the oauth access token response
const sfApiVersion = '47.0'

/*
    sf.username = shan@radiantt.com.oceandsg1
sf.password = Welcome@20196dKW4jxvJNFfeWqg7SNAYzBcV
sf.serverurl = https://ocean1--oceandsg1.my.salesforce.com
*/

//App Constants
const port = 8081 // AWS nginx uses port 8081
//const authCallbackUrl = 'http://localhost:' + port + '/callback'
const SaviQueueName = 'Savi_SQS.fifo'
//The Base String used to generate MessageDeduplicationId at runtime
const SAVIQueueMessgaeDeduplicationBaseString = "SAVIREQCID"
//
const SAVIQueueMessgaeGroupID = 'SAVIREQCONTENTID'
//Savi FIFO Queue url
const SAVIQueueURL = 'https://sqs.us-east-2.amazonaws.com/014463521951/Savi_SQS.fifo'

//Clam AV (Local Development)
const CLAMAVServiceURL = 'http://localhost:9100/'

module.exports = {
    oauthAccessTokenHost,
    oauthAccessTokenPath,
    sfUserName,
    sfPassword,
    oauthSecurityToken,
    clientID,
    clientSecret,
    sfOrgURL,
    sfApiVersion,
    port,
    SaviQueueName,
    SAVIQueueMessgaeDeduplicationBaseString,
    SAVIQueueMessgaeGroupID,
    SAVIQueueURL,
    CLAMAVServiceURL
}