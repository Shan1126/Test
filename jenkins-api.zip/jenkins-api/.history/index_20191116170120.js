/*jshint esversion: 8*/

const express = require('express');
const bodyParser = require('body-parser');
const appConstants = require('./constants');
const app = express();
const logger = require('./logger/simple-logger');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));

const fileValidateRouter = require('./routes/filevalidate');

// const authenticateRouter = require('./authenticate')
app.get('/', (req, res) => {        
    res.send({ServiceName : 'SF_FileCheck Service', 'Time' : (new Date()).toString()});    
});

app.get('/favicon.ico', (req, res) => res.status(204));

// app.use('/', authenticateRouter)
app.use('/fileValidate', fileValidateRouter);

app.listen(appConstants.port, () => {
    logger.writeInfoLog('SAVI Service running on port ', appConstants.port);
    console.log(`SAVI Service running on port ${appConstants.port}`);
});

app.use('/api/v1/scanfile', require('./routes/savi-controller'));
app.use('/api/v1/jenkins', require('./routes/jenkins.controller'));
