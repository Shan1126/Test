/*jshint esversion: 8*/

const express = require('express');
const bodyParser = require('body-parser');
var cors = require('cors');
const logger = require('./logger/simple-logger');
const dotenv = require('dotenv');
const config = require('./config.json');
const expressConfiguration = require("./express-config");

const jwt = require('/jwt');

const app = express();
app.set('superSecret', config.secret);
dotenv.config();
expressConfiguration.init(app, express);
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));


const allowCrossDomain = function (req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Max-Age', '1000');
    res.header('Access-Control-Allow-Methods', 'GET, PUT, POST, DELETE, HEAD, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'x-requested-with, Content-Type, origin, authorization, accept, client-security-token');
    next();
};


const apiRoutes = express.Router();
apiRoutes.use(function (req, res, next) {
    // check header or url parameters or post parameters for token
    const jobName = req.params.name;
    if (jobName) {
        if(process.env.allowedJobs.include(jobName)) {
            next();
        }
    } else {
       console.log('Invalid job');
        return res.status(403).send({
            success: false,
            message: 'Invalid job.'
        });
    }
});

app.use(cors());
app.use(allowCrossDomain);

app.listen(8081, () => {
    logger.writeInfoLog('Jenkins middleware Service running on port ', 8081);
    console.log(`Jenkins middleware Service running on port 8081`);
});
app.use('/api/v1/jenkins/jobs', require('./routes/jenkins.controller'));
app.use('/np/users', require('./controllers/authenticate.controller'));
