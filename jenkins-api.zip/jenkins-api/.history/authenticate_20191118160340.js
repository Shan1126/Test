/*jshint esversion: 8*/
/*
    Authentication for using Salesforce API
    Salesforce uses OAuth2.0
*/
var express = require('express');
var router = express.Router();
const appConstants = require('./constants');
var logger = require('./logger/simple-logger');

const credentials = {
    client: {
        id: appConstants.clientID,
        secret: appConstants.clientSecret
    },
    auth: {
        tokenHost: appConstants.oauthAccessTokenHost,
        tokenPath: appConstants.oauthAccessTokenPath
    },
    options : {
        authorizationMethod : 'body'
    }
};

const tokenConfig = {    
    username: appConstants.sfUserName,
    password: appConstants.sfPassword + appConstants.oauthSecurityToken    
};

const oauth2 = require('simple-oauth2').create(credentials);

async function getAccessToken() {

    try {
        logger.writeInfoLog('Requesting OAuth Token');       
        const authResult = await oauth2.ownerPassword.getToken(tokenConfig);
        const oauthToken = oauth2.accessToken.create(authResult);
        logger.writeInfoLog('OAuth Token successfully received');
        return oauthToken;
    } catch (err) {
        console.log('Oauth Error : ' + err.message);
        logger.writeErrorLog('Error while trying to receive OAuth Token ' +err.message);
        return null;
    }    

}

module.exports = function(){
    return getAccessToken();
};