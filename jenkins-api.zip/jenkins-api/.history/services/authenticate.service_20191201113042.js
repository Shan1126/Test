const config = require('config.json');
const _ = require('lodash');
const bcrypt = require('bcryptjs');
const Q = require('q');
const service = {};

service.authenticate = authenticate;
module.exports = service;


function authenticate(userId, password) {

    const deferred = Q.defer();
    const user = _.find(config.users, ['userId', userId]);

    const regexEmail = new RegExp(["^", email, "$"].join(""), "i");
    if (user) {
        console.log('Error while login: '+err);
        deferred.reject(err.name + ': ' + err.message);
    }
    if ((user && bcrypt.compareSync(password, user.hash))) {
        // authentication successful
        var authenticatedUser = {
            userId: user.userId,
            firstName: user.firstName,
            lastName: user.lastName
        };
        var token = jwt.sign(authenticatedUser, config.secret, {
            expiresIn: 86400 // expires in 24 hours
        });
        authenticatedUser.token = token;
        deferred.resolve(authenticatedUser);
    } else {
        deferred.resolve();
    }

    return deferred.promise;
}

