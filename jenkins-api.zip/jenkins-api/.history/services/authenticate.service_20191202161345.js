const config = require('../config.json');
const _ = require('lodash');
const Q = require('q');
var jwt = require('jsonwebtoken');
const service = {};
const logger = require('../logger/simple-logger');

service.authenticate = authenticate;
module.exports = service;


function authenticate(userId, password) {
    console.log('Username: ' +useri)
    const deferred = Q.defer();
    console.log()
    var user = _.find(config.users, function(u){ return u.userId ===  userId});

    if (!user) {
        logger.writeInfoLog("User not found in config: " + userId);
        console.log("User not found in config: " + userId);
        deferred.reject("User not found in config " );
    }
    if ((user && (password == user.password))) {
        logger.writeInfoLog("Logged in User : " + userId);
        console.log("Logged in User : " + userId);
        // authentication successful
        var authenticatedUser = {
            userId: user.userId,
            firstName: user.firstName,
            lastName: user.lastName
        };
        var token = jwt.sign(authenticatedUser, config.secret, {
            expiresIn: 86400 // expires in 24 hours
        });
        authenticatedUser.token = token;
        deferred.resolve(authenticatedUser);
    } else {
        deferred.resolve();
    }

    return deferred.promise;
}

