var config = require('config.json');
var _ = require('lodash');
var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');
var Q = require('q');

var mongo = require('mongoskin');
var moment = require('moment');
var parseString = require('xml2js').parseString;
var db = mongo.db(process.env.SMARTSUB_MONGODB_CONNECTION_STRING, { native_parser: true });
db.bind('users');
db.bind('company');
db.bind('candidate');
db.bind('projects');
db.bind('invitation');
db.bind('position');
db.bind('cities');

var ObjectId = require('mongodb').ObjectID;
var audit = require('services/audit.service');
const cryptoRandomString = require('crypto-random-string');
var async = require('async');
var emailService = require('services/email.service');
var service = {};
var uuid = require('uuid');


service.authenticate = authenticate;
module.exports = service;


function authenticate(email, password) {

    var deferred = Q.defer();

    var regexEmail = new RegExp(["^", email, "$"].join(""), "i");
    db.users.findOne({email: regexEmail}, function (err, user) {
        if (err) {
            console.log('Error while login: '+err);
            deferred.reject(err.name + ': ' + err.message);
        }
        if ((user && bcrypt.compareSync(password, user.hash))) {
            // authentication successful
            var authenticatedUser = {
                _id: user._id,
                userId: user.userId,
                firstName: user.firstName,
                lastName: user.lastName,
                email: user.email,
                isActive: user.isActive,
                contactNumber: user.phoneNumber || '',
                type: user.type,
                companyName: user.companyName || '',
                companyId: user.companyId || '',
                companyType: user.companyType,
                type: user.type,
                workTitle: user.workTitle || '',
                workAddress: user.workAddress || '',
                workCity: user.workCity || '',
                workState: user.workState || '',
                workZip: user.workZip || '',
                authVerified: false,
                vendors: user.vendors,
                isAuthEnabled: user.isAuthEnabled || false,
                preferences: user.preferences || [],
                token: jwt.sign({ sub: user._id }, config.secret)
            };
            var token = jwt.sign(authenticatedUser, config.secret, {
                expiresIn: 86400 // expires in 24 hours
            });
            authenticatedUser.token = token;
            deferred.resolve(authenticatedUser);
        } else {
            deferred.resolve();
        }
    });

    return deferred.promise;
}

