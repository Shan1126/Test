var config = require('config.json');
var _ = require('lodash');
var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');
var Q = require('q');
const rp = require('request-promise');
var random = require('random-number');

var mongo = require('mongoskin');
var moment = require('moment');
var parseString = require('xml2js').parseString;
var db = mongo.db(process.env.SMARTSUB_MONGODB_CONNECTION_STRING, { native_parser: true });
db.bind('users');
db.bind('company');
db.bind('candidate');
db.bind('projects');
db.bind('invitation');
db.bind('position');
db.bind('cities');

var ObjectId = require('mongodb').ObjectID;
var audit = require('services/audit.service');
const cryptoRandomString = require('crypto-random-string');
var async = require('async');
var emailService = require('services/email.service');
var service = {};
var uuid = require('uuid');


service.authenticate = authenticate;
service.searchJobs = searchJobs;
service.verifyToken = verifyToken;
service.changePass = changePass;
service.create = create;
service.forgotPassword = forgotPassword;
service.getLocations = getLocations;
service.getInvitedUser = getInvitedUser;
service.confirmEmail = confirmEmail;
service.checkCompany = checkCompany;
module.exports = service;


function checkCompany(req) {
    var deferred = Q.defer();
    var exists = false;
    var exists1 = false;

    async.series([
        function (callback) {
            var website = req.body.website.replace(/^(?:https?:\/\/)?(?:www\.)?/i, "").split('/')[0];
            var https_www = 'https://www.'+ website;
            var http_www = 'http://www.'+website;
            var https = 'https://'+website;
            var http = 'http://'+website;
            var www = 'www.'+website;
            var defaultQ = {};
            defaultQ['$or'] = [];
            defaultQ['$or'].push({website: https_www});
            defaultQ['$or'].push({website: http_www});
            defaultQ['$or'].push({website: https});
            defaultQ['$or'].push({website: http});
            defaultQ['$or'].push({website: www});
            db.company.findOne(defaultQ, function (dbErr, company) {
                if (dbErr) callback(dbErr);
                if (company) {
                    exists = true;
                } else {
                    exists = false;
                }
                callback(null);
            });
        },
        function (callback) {
            if(!exists) {
                var defaultQ1 = {};
                defaultQ1['$or'] = [];
                defaultQ1['$or'].push({companyName: req.body.companyName});
                db.company.findOne(defaultQ1, function (dbErr, company) {
                    if (dbErr) callback(dbErr);
                    if (company) {
                        exists1 = true;
                    } else {
                        exists1 = false;
                    }
                });
            }
            callback(null);


        }
    ], function (err, cs) {
        if (err) {
            deferred.reject(err.name + ': ' + err.message)
        }
        if (exists || exists1) {
            deferred.resolve('404');
        } else {
            deferred.resolve('200');
        }
    });

    return deferred.promise;
}
function generateConfirmationcode(companyName) {
    var gen = random.generator({
        min:  0
        , max:  1000000
        , integer: true
    });
    return companyName.substring(0,2).toUpperCase() +gen(200000);
}

function getInvitedUser(req) {
    var deferred = Q.defer();
    db.invitation.findOne({_id:new ObjectId(req.params._id), isActive: true}, function(err, invite) {
        if(err) {
            deferred.reject(err);
        } else if(invite) {
            deferred.resolve(invite);
        } else{
            deferred.reject('Invalid Invitation Code');
        }
    });
    return deferred.promise;
}

function confirmEmail(req) {
    var deferred = Q.defer();
    var set = {};
    set.isActive =  true;
    set.email_confirmed_date = new Date();
    var query = { confirmationCode: req.body.confirmationCode, isActive: false };
    async.series([
        function (callback) {
            db.users.findOne(query, function (dbErr, user) {
                if (dbErr) cb(dbErr);
                if (!user) {
                    deferred.reject('Invalid confirmation code.');
                }
                callback(null);
            });
        },
        function () {
            db.users.update(
                query,
                {$set: set},
                function (err, doc) {
                    if (err) deferred.reject(err.name + ': ' + err.message);
                    deferred.resolve();
                }
            );
        }
    ]);
    return deferred.promise;
}

function confirmEmail(req) {
    var deferred = Q.defer();
    var set = {};
    set.isActive =  true;
    set.email_confirmed_date = new Date();
    var query = { confirmationCode: req.body.confirmationCode, isActive: false };
    async.series([
        function (callback) {
            db.users.findOne(query, function (dbErr, user) {
                if (dbErr) cb(dbErr);
                if (!user) {
                    deferred.reject('Invalid confirmation code.');
                }
                callback(null);
            });
        },
        function () {
            db.users.update(
                query,
                {$set: set},
                function (err, doc) {
                    if (err) deferred.reject(err.name + ': ' + err.message);
                    deferred.resolve();
                }
            );
        }
    ]);
    return deferred.promise;
}

function getLocations(req, res) {
    var deferred = Q.defer();
    var searchQuery = {};
    var regEx = new RegExp('^' + req.body.searchQ, 'i');
    if(!isNaN(req.body.searchQ)) {
        searchQuery.zips =  parseInt(req.body.searchQ);
    } else {
        searchQuery.city = regEx;
    }
    db.cities.find(searchQuery)
        .sort({city: 1}).limit(8)
        .toArray(function (err, locations) {
            if (err) {
                deferred.reject('Somme issues while searching locations' + err);
            }
            locations.forEach(function (i){
                i.cityState = i.city + ', '+ i.state_id;
            });
            if(!isNaN(req.body.searchQ)) {
                deferred.resolve(locations);
            } else {
                const set = new Set();
                const result = [];
                locations.forEach(function (i){
                    if(!set.has(i.cityState)) {
                        set.add(i.cityState);
                        result.push(i);
                    }
                });
                deferred.resolve(result);
            }
    });
    return deferred.promise;
}


function authenticate(email, password) {

    var deferred = Q.defer();

    var regexEmail = new RegExp(["^", email, "$"].join(""), "i");
    db.users.findOne({email: regexEmail}, function (err, user) {
        if (err) {
            console.log('Error while login: '+err);
            deferred.reject(err.name + ': ' + err.message);
        }
        if ((user && bcrypt.compareSync(password, user.hash))) {
            // authentication successful
            var authenticatedUser = {
                _id: user._id,
                userId: user.userId,
                firstName: user.firstName,
                lastName: user.lastName,
                email: user.email,
                isActive: user.isActive,
                contactNumber: user.phoneNumber || '',
                type: user.type,
                companyName: user.companyName || '',
                companyId: user.companyId || '',
                companyType: user.companyType,
                type: user.type,
                workTitle: user.workTitle || '',
                workAddress: user.workAddress || '',
                workCity: user.workCity || '',
                workState: user.workState || '',
                workZip: user.workZip || '',
                authVerified: false,
                vendors: user.vendors,
                isAuthEnabled: user.isAuthEnabled || false,
                preferences: user.preferences || [],
                token: jwt.sign({ sub: user._id }, config.secret)
            };
            var token = jwt.sign(authenticatedUser, config.secret, {
                expiresIn: 86400 // expires in 24 hours
            });
            authenticatedUser.token = token;
            deferred.resolve(authenticatedUser);
        } else {
            deferred.resolve();
        }
    });

    return deferred.promise;
}

function verifyToken(req) {
    // console.log('forgotPassword: '+req.body.username);
    var token = req.body.token;
    var deferred = Q.defer();
    // console.log(set);
    var userObj;

    db.users.findOne({ resetToken: token },
        function (dbErr, user) {
            if (dbErr) {
                console.error('Error: ' + dbErr);
                deferred.reject(err.name + ': ' + err.message);
            }
            if (user !== undefined) {
                userObj = user;
                deferred.resolve();
            }
            else {
                deferred.reject();
            }
        });
    return deferred.promise;
}

function changePass(req) {
    var token = req.body.token;
    var deferred = Q.defer();
    var set = {};
    set.hash = bcrypt.hashSync(req.body.newPassword, 10);
    set.last_updated_date = new Date();
    set.resetToken = '';
    var abort = false;
    var userObj;

    async.series([
        function (callback) {
            db.users.findOne({ resetToken: token },
                function (dbErr, user) {
                    if (dbErr) {
                        console.error('Error: ' + dbErr);
                        callback(dbErr);
                    }
                    if (user) {
                        userObj = user;
                    } else {
                        abort = true;
                    }
                    callback(null);
                })
        },
        function (callback) {
            if (!abort) {
                db.users.update(
                    {email: userObj.email},
                    {$set: set},
                    function (dbErr, result) {
                        if (dbErr) cb(dbErr);
                    })
            }
            callback(null);
        }
    ], function (err) {
        if (err) {
            deferred.reject(err.name + ': ' + err.message)
        }
        deferred.resolve();
    });

    return deferred.promise;
}

function forgotPassword(req) {
    var username = req.body.username;
    var deferred = Q.defer();
    var set = {};
    var resetToken = cryptoRandomString(10);
    set.last_updated_date = new Date();
    set.resetToken = resetToken;
    var userObj;
    var abort = false;
    async.series([
        function (callback) {
            db.users.findOne({ email: username },
                function (dbErr, user) {
                    if (dbErr) {
                        console.error('Error: ' + dbErr);
                        callback(dbErr);
                    }
                    if (user) {
                        userObj = user;
                    }
                    else {
                        abort = true;
                        deferred.reject('No User found');
                    }
                    callback(null);
                })
        },
        function (callback) {
            if (!abort) {
                db.users.update(
                    {email: username},
                    {$set: set},
                    function (dbErr, result) {
                        if (dbErr) cb(dbErr);
                })
            }
            callback(null);

        },
        function (callback) {
            if (!abort) {
                var data = {};
                data.toEmail = userObj.email;
                data.subject = 'Reset your password';
                data.title = 'Password reset email';
                data.name = userObj.lastName + ', ' + userObj.firstName;
                data.emailSubject = 'Reset your password!';
                data.buttonText = 'Reset Password';
                data.buttonLinkUrl =  process.env.SS_URL+'/reset-password?token=' + resetToken;
                data.paragraph_1 = 'Please click on the below button to confirm your email for SmartSubmissions, a new and smarter way to find jobs.';
                emailService.inviteUser(data, req)
                    .then(function(result) {

                    }, function(error) {
                        deferred.reject('Email notification failed: '+ error)
                    }).catch(function () {
                    deferred.reject('Email notification failed')
                });
            }
            callback(null);
        }


    ], function (err) {
        if (err) {
            deferred.reject(err.name + ': ' + err.message);
        }
        deferred.resolve();
    });

    return deferred.promise;
}



