var config = require('config.json');
var _ = require('lodash');
var bcrypt = require('bcryptjs');
var Q = require('q');
var service = {};


service.authenticate = authenticate;
module.exports = service;


function authenticate(email, password) {

    var deferred = Q.defer();

    var regexEmail = new RegExp(["^", email, "$"].join(""), "i");
    db.users.findOne({email: regexEmail}, function (err, user) {
        if (err) {
            console.log('Error while login: '+err);
            deferred.reject(err.name + ': ' + err.message);
        }
        if ((user && bcrypt.compareSync(password, user.hash))) {
            // authentication successful
            var authenticatedUser = {
                userId: user.userId,
                firstName: user.firstName,
                lastName: user.lastName,
                token: jwt.sign({ sub: user.userId }, config.secret)
            };
            var token = jwt.sign(authenticatedUser, config.secret, {
                expiresIn: 86400 // expires in 24 hours
            });
            authenticatedUser.token = token;
            deferred.resolve(authenticatedUser);
        } else {
            deferred.resolve();
        }
    });

    return deferred.promise;
}

