/*jshint esversion: 8*/

const express = require('express');
const bodyParser = require('body-parser');
var cors = require('cors');
const app = express();
const logger = require('./logger/simple-logger');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));
var allowCrossDomain = function (req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Max-Age', '1000');
    res.header('Access-Control-Allow-Methods', 'GET, PUT, POST, DELETE, HEAD, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'x-requested-with, Content-Type, origin, authorization, accept, client-security-token');
    next();
};



app.use(cors());
app.use(allowCrossDomain);

app.listen(8081, () => {
    logger.writeInfoLog('Jenkins middleware Service running on port ', appConstants.port);
    console.log(`Jenkins middleware Service running on port ${appConstants.port}`);
});
app.use('/api/v1/jenkins/jobs', require('./routes/jenkins.controller'));
