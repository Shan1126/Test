/*jshint esversion: 8*/

const express = require('express');
const bodyParser = require('body-parser');
var cors = require('cors');
const logger = require('./logger/simple-logger');
const dotenv = require('dotenv');
var config = require('./config.json');
var jwt = require('jsonwebtoken');
const app = express();
app.set('superSecret', config.secret);
dotenv.config();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));

const allowCrossDomain = function (req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Max-Age', '1000');
    res.header('Access-Control-Allow-Methods', 'GET, PUT, POST, DELETE, HEAD, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'x-requested-with, Content-Type, origin, authorization, accept, client-security-token');
    next();
};


const apiRoutes = express.Router();

apiRoutes.use(function (req, res, next) {
    // check header or url parameters or post parameters for token
    var token = req.body.token || req.query.token || req.headers['x-access-token'];
    if (token) {
        jwt.verify(token, app.get('superSecret'), function (err, decoded) {
            if (err) {
                return res.json({success: false, message: 'Failed to authenticate token.'});
            } else {
                req.decoded = decoded;
                next();
            }
        });
    } else {
       console.log('No token provided');
        return res.status(403).send({
            success: false,
            message: 'No token provided.'
        });

    }
});


apiRoutes.use(function (req, res, next) {
    // check header or url parameters or post parameters for token
    const jobName = req.params.name;
    if (jobName) {
        if(process.env.allowedJobs.include(jobName)) {
            next();
        }
        else {
            console.log('Invalid job');
             return res.status(403).send({
                 success: false,
                 message: 'Invalid job.'
             });
        }
    } 
});

app.use(cors());
app.use(allowCrossDomain);

// routes
app.use('/api', apiRoutes);

app.get('/', function (req, res) {
    res.send('Welcome to Jenkins API application!');
});


app.listen(8081, () => {
    logger.writeInfoLog('Jenkins middleware Service running on port ', 8081);
    console.log(`Jenkins middleware Service running on port 8081`);
});
app.use('/api/v1/jenkins/jobs', require('./routes/jenkins.controller'));
app.use('/np/users', require('./routes/authenticate.controller'));

app.listen(process.env.PORT || port, host);
logger.info("Listening on " + port);
module.exports = app;