const express = require("express");
const https = require("https");
var request = require("request");
var parser = require("xml2json");
var cronParser = require("cron-parser");

const router = express.Router();
var config = require("./../config.json");
const logger = require("../logger/simple-logger");
const jenkins = require("jenkins")({
  baseUrl: process.env.jenkins_url,
  crumbIssuer: true
});

// routes
router.get("/:name", getJobByName);
router.post("/", getNextRunTime);
router.get("/:name/:buildNumber", getBuildDetails);
router.get("/", getAllJobs);
router.post('/:name', buildJob);
router.get("/:name/:buildNumber/log", getConsoleLog);
module.exports = router;

process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = 0;

function getConsoleLog(req, res) {
  if (req.params.name) {
    jenkins.build.log(req.params.name, req.params.buildNumber, function (
      err,
      data
    ) {
      if (err) {
        return console.log(err);
      }
      res.status(200).send({ data: data });
    });
  } else {
    res.status(200).send({});
  }
}

function jobs(req, res) {
  jenkins.info(function (err, data) {
    if (err) throw err;
    var lst = [];
    data.jobs.forEach(j => {
      if (config.allowedApps.indexOf(j.name) > -1) {
        lst.push(j);
      }
    });
    data.jobs = lst;
    res.status(200).send(data);
  });
}
function getJobByName(req, res) {
  if (req.params.name) {
    jenkins.job.get(req.params.name, function (err, data) {
      if (err) {
        console.log(err);
      }
      res.status(200).send(data);
    });
  } else {
    res.status(200).send({});
  }
}
function getAllJobs(req, res) {
  request(process.env.jenkins_url + config.getJobsUrl, function (
    error,
    response,
    body
  ) {
    if (body === undefined) {
      res.status(200).send({});
    } else {
      // console.log('Body:' + JSON.stringify(body))
      const b = JSON.parse(body);
      const jobs = b.jobs;
      var lst = [];
      var j = {};
      jobs.forEach(j => {
        if (j.jobs) {
          j.jobs.forEach(h => {
            if (config.allowedApps.includes(h.name)) {
              lst.push(h);
            }
          });
        }
        if (config.allowedApps.includes(j.name)) {
          lst.push(j);
        }
      });
      j.jobs = lst;
      res.status(200).send(j);
    }
  });
}
function getNextRunTime(req, res) {
  logger.writeInfoLog("Getting next run time for job: " + req.body.jobName);
  var job = {};
  request(
    process.env.jenkins_url + "/job/" + req.body.jobName + "/config.xml",
    function (error, response, body) {
      if (body != undefined) {
        var jsonObj;
        try {
          jsonObj = JSON.parse(parser.toJson(body));
        } catch (e) {
          logger.writeInfoLog(e);
          logger.writeInfoLog("Error occurred while getting xml file for the job: " + req.body.jobName);
        }
        //console.log('JSON: ' + JSON.stringify(jsonObj));
        if (
          jsonObj &&
          jsonObj.project &&
          jsonObj.project.triggers &&
          jsonObj.project.triggers["hudson.triggers.TimerTrigger"] &&
          jsonObj.project.triggers["hudson.triggers.TimerTrigger"].spec
        ) {
          var interval = cronParser.parseExpression(
            jsonObj.project.triggers["hudson.triggers.TimerTrigger"].spec
          );
          job.nextTime = interval.next();
          logger.writeInfoLog("Got next run time for job: " + req.body.jobName);
          res.status(200).send(job);
        }
        else {
          logger.writeInfoLog("No next run time for job: " + req.body.jobName);
          res.status(200).send(null);
        }
      } else {
        logger.writeInfoLog("No next run time for job: " + req.body.jobName);
        res.status(200).send(null);
      }
    }
  );
}
function getBuildDetails(req, res) {
  if (req.params.name) {
    jenkins.build.get(req.params.name, req.params.buildNumber, function (
      err,
      data
    ) {
      if (err) {
        return console.log(err);
      }
      res.status(200).send(data);
    });
  } else {
    res.status(200).send({});
  }
}

function buildJob(req, res) {
  if (req.params.name) {
    logger.writeInfoLog("Building job: " + req.body.jobName);
    jenkins.job.build(req.params.name, function (err, id) {
      if (err) throw err;
      waitOnQueue(id);
      logger.writeInfoLog("job scheduled to start job: " + req.body.jobName);
      res.status(200).send({message: 'Job has been started'});
    });
  } else {
    waitOnQueue(id);
    res.status(200).send({});
  }
}
function waitOnQueue(id) {
  jenkins.queue.item(id, function (err, item) {
    if (err) throw err;
    console.log("queue", item);
    if (item.executable) {
      console.log("number:", item.executable.number);
      return item.executable.number;
    } else if (item.cancelled) {
      console.log("cancelled");
      return "canceled";
    } else {
      setTimeout(function () {
        waitOnQueue(id);
      }, 500);
    }
  });
}













